"use client";

import React, { useMemo, useReducer, useEffect, useCallback, useRef, useState } from "react";

type Suit = "Spade" | "Heart" | "Diamond" | "Club" | "Crown" | "Key" | "Star";
type Phase = "LOBBY" | "PLAYER" | "DEALER" | "DONE";

type Card = {
  suit: Suit;
  value: number; // 1..11
  rank: number; // 1 = highest suit rank
  id: string; // `${Suit}-${value}`
};

const SUITS: Suit[] = ["Spade", "Heart", "Diamond", "Club", "Crown", "Key", "Star"];
const SUIT_RANK: Record<Suit, number> = {
  Spade: 1,
  Heart: 2,
  Diamond: 3,
  Club: 4,
  Crown: 5,
  Key: 6,
  Star: 7,
};
const VALUES = Array.from({ length: 11 }, (_, i) => i + 1);

const BUST = 21.0;
const DEALER_STAND = 17.0;

const MAX_BET = 50;
const AUTO_SHUFFLE_BEFORE_DEAL_IF_DECK_LT = 12;

// Bonuses (STABLE except pct tuning)
const PLAYER_WIN_BONUS_PCT = 0.091; // tuned toward ~1.677% max edge target
const TRIPLE7_EXTRA_MULT = 2; // + (bet * 2) even if bust (special exception)

// Progressive pot (STABLE)
const JACKPOT_BASE_POT = 777;
const JACKPOT_CONTRIB_PER_HAND = 1; // 1 sat per resolved hand

// Base progressive condition (STABLE)
const JACKPOT_TRIGGER_TOTAL = 17.17;
const JACKPOT_HAND_MOD = 21;

// KEY (agency gating) - LOGIC ONLY
const KEY_TTL_HANDS = 21; // still used for HELD expiry
const KEY_HEADLESS_ACTIVATE_P = 0.2; // headless-only "player chooses to activate"
const JACKPOT_MICROROLL_P = 0.333; // tuning knob

// Headless rules
const HEADLESS_CASINO_BANK_START = 100_000;
const HEADLESS_CHUNK_HANDS = 2000;
const HEADLESS_INFINITE_BANKROLL = 9_000_000_000_000_000;

function round2(n: number) {
  return Math.round(n * 100) / 100;
}

function eq2(a: number, b: number) {
  return round2(a) === round2(b);
}

function cryptoSeed32(): number {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return (arr[0] >>> 0) || 1;
}

function randFloat01(): number {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return arr[0] / 0xffffffff;
}

function buildDeck(): Card[] {
  const deck: Card[] = [];
  for (const suit of SUITS) {
    for (const v of VALUES) {
      deck.push({
        suit,
        value: v,
        rank: SUIT_RANK[suit],
        id: `${suit}-${v}`,
      });
    }
  }
  return deck; // 77 unique
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const r = new Uint32Array(1);
    crypto.getRandomValues(r);
    const j = r[0] % (i + 1);
    const tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
  }
  return a;
}

// Approved scoring: value + rank/100, rounded to 2 decimals.
function cardScore(c: Card): number {
  return round2(c.value + c.rank / 100);
}

function handTotal(hand: Card[]): number {
  return round2(hand.reduce((sum, c) => sum + cardScore(c), 0));
}

function clampBet(n: number) {
  const x = Math.trunc(n);
  if (x < 0) return 0;
  if (x > MAX_BET) return MAX_BET;
  return x;
}

function hasDuplicatesById(cards: Card[]): boolean {
  const seen = new Set<string>();
  for (const c of cards) {
    if (seen.has(c.id)) return true;
    seen.add(c.id);
  }
  return false;
}

// NEVER return a card already inPlay, and never duplicate within the same take.
function takeUnique(deck: Card[], n: number, inPlay: Set<string>): { taken: Card[]; rest: Card[] } {
  let d = [...deck];
  const taken: Card[] = [];
  const takenIds = new Set<string>();

  if (hasDuplicatesById(d)) {
    d = shuffle(buildDeck().filter((c) => !inPlay.has(c.id)));
  }

  let safety = 0;
  while (taken.length < n) {
    safety++;
    if (safety > 500) {
      const blocked = new Set<string>([...inPlay, ...takenIds]);
      d = shuffle(buildDeck().filter((c) => !blocked.has(c.id)));
      safety = 0;
    }

    if (d.length === 0) {
      const blocked = new Set<string>([...inPlay, ...takenIds]);
      d = shuffle(buildDeck().filter((c) => !blocked.has(c.id)));
      continue;
    }

    const c = d.shift()!;
    if (inPlay.has(c.id)) continue;
    if (takenIds.has(c.id)) continue;

    taken.push(c);
    takenIds.add(c.id);
    inPlay.add(c.id);
  }

  return { taken, rest: d };
}

type LastHandFlags = {
  outcome: "WIN" | "LOSS" | "PUSH" | "NONE";
  bonusWinPaid: number;
  triple7Paid: number;
  seventhHandPaid: number;
  jackpotPaid: number;
  jackpotBaseEligible: boolean;
  jackpotKeyEligible: boolean;
  jackpotMicroPass: boolean;
  keyEarned: boolean;
  keyActivated: boolean;
  keyConsumed: boolean;
  keyExpiredHeld: boolean;
};

type HeadlessStats = {
  wins: number;
  losses: number;
  pushes: number;

  playerFinalCards_2: number;
  playerFinalCards_3: number;
  playerFinalCards_4: number;
  playerFinalCards_5: number;
  playerFinalCards_6: number;
  playerFinalCards_7p: number;

  freq4SameSuit: number;
  freq5SameSuit: number;

  freq3Run: number;
  freq4Run: number;

  uniqSuits4: number;
  uniqSuits5: number;
  uniqSuits6: number;
  uniqSuits7: number;

  exact21: number;
  exact1717: number;

  handsWith7: number;
  handsWith2x7: number;
  handsWith3x7: number;
  total7CardsDealtToPlayer: number;

  bonusPaidWinBonus: number;
  bonusPaidTriple7: number;
  bonusPaidSeventhHand: number;

  jackpotContribTotal: number;
  jackpotHits: number;
  jackpotPaidTotal: number;

  jackpotBaseEligible: number;
  jackpotKeyEligible: number;
  jackpotMicroPass: number;

  keyEarned: number;
  keyActivated: number;
  keyConsumed: number;
  keyExpiredHeld: number;
};

const emptyHeadlessStats = (): HeadlessStats => ({
  wins: 0,
  losses: 0,
  pushes: 0,

  playerFinalCards_2: 0,
  playerFinalCards_3: 0,
  playerFinalCards_4: 0,
  playerFinalCards_5: 0,
  playerFinalCards_6: 0,
  playerFinalCards_7p: 0,

  freq4SameSuit: 0,
  freq5SameSuit: 0,

  freq3Run: 0,
  freq4Run: 0,

  uniqSuits4: 0,
  uniqSuits5: 0,
  uniqSuits6: 0,
  uniqSuits7: 0,

  exact21: 0,
  exact1717: 0,

  handsWith7: 0,
  handsWith2x7: 0,
  handsWith3x7: 0,
  total7CardsDealtToPlayer: 0,

  bonusPaidWinBonus: 0,
  bonusPaidTriple7: 0,
  bonusPaidSeventhHand: 0,

  jackpotContribTotal: 0,
  jackpotHits: 0,
  jackpotPaidTotal: 0,

  jackpotBaseEligible: 0,
  jackpotKeyEligible: 0,
  jackpotMicroPass: 0,

  keyEarned: 0,
  keyActivated: 0,
  keyConsumed: 0,
  keyExpiredHeld: 0,
});

type State = {
  seed: number;
  phase: Phase;

  deck: Card[];
  playerHand: Card[];
  dealerHand: Card[];

  bankroll: number;
  bet: number;

  casinoBank: number;
  jackpotPot: number;

  handIndex: number;
  streakWins: number;
  last7Bets: number[];

  message: string;

  playerInitialBust: boolean;

  playerHitThisHand: boolean;
  made1717ViaDraw: boolean;

  // KEY state
  keyHeld: boolean;
  keyHeldTtl: number; // HELD expires normally (still TTL)
  keyActive: boolean; // ACTIVE does NOT expire; waits for next baseEligible window
  keyActiveWaitHands: number; // how many resolved hands it has waited

  // Activation bookkeeping: survives START resetting `last`
  keyActivatedPending: boolean;

  last: LastHandFlags;

  // Headless stats
  headlessActive: boolean;
  headlessTargetHands: string;
  headlessHandsDone: number;
  headlessHouseNet: number;
  headlessTotalWagered: number;
  headlessAvgBet: number;
  headlessEdgePct: number;
  headlessBroke: boolean;

  headlessStats: HeadlessStats;
};

type Action =
  | { type: "RESET_RUN" }
  | { type: "SHUFFLE" }
  | { type: "RESET_BET" }
  | { type: "BET_ADD"; inc: number }
  | { type: "BET_PLACE_CTA" }
  | { type: "START" }
  | { type: "DRAW"; n: 1 | 2 }
  | { type: "STAND" }
  | { type: "DEALER_PLAY" }
  | { type: "NEXT_HAND" }
  | { type: "ACTIVATE_KEY" }
  | {
      type: "HEADLESS_APPLY";
      next: Pick<
        State,
        | "seed"
        | "phase"
        | "deck"
        | "playerHand"
        | "dealerHand"
        | "bankroll"
        | "bet"
        | "casinoBank"
        | "jackpotPot"
        | "handIndex"
        | "streakWins"
        | "last7Bets"
        | "message"
        | "playerInitialBust"
        | "playerHitThisHand"
        | "made1717ViaDraw"
        | "keyHeld"
        | "keyHeldTtl"
        | "keyActive"
        | "keyActiveWaitHands"
        | "keyActivatedPending"
        | "last"
        | "headlessActive"
        | "headlessTargetHands"
        | "headlessHandsDone"
        | "headlessHouseNet"
        | "headlessTotalWagered"
        | "headlessAvgBet"
        | "headlessEdgePct"
        | "headlessBroke"
        | "headlessStats"
      >;
    }
  | { type: "HEADLESS_SET_ACTIVE"; active: boolean };

const emptyLast = (): LastHandFlags => ({
  outcome: "NONE",
  bonusWinPaid: 0,
  triple7Paid: 0,
  seventhHandPaid: 0,
  jackpotPaid: 0,
  jackpotBaseEligible: false,
  jackpotKeyEligible: false,
  jackpotMicroPass: false,
  keyEarned: false,
  keyActivated: false,
  keyConsumed: false,
  keyExpiredHeld: false,
});

const initialState: State = {
  seed: cryptoSeed32(),
  phase: "LOBBY",
  deck: shuffle(buildDeck()),
  playerHand: [],
  dealerHand: [],
  bankroll: 10000,
  bet: 0,

  casinoBank: HEADLESS_CASINO_BANK_START,
  jackpotPot: JACKPOT_BASE_POT,

  handIndex: 0,
  streakWins: 0,
  last7Bets: [],

  message: "Place a bet to join the table.",
  playerInitialBust: false,

  playerHitThisHand: false,
  made1717ViaDraw: false,

  keyHeld: false,
  keyHeldTtl: 0,
  keyActive: false,
  keyActiveWaitHands: 0,
  keyActivatedPending: false,

  last: emptyLast(),

  headlessActive: false,
  headlessTargetHands: "10000",
  headlessHandsDone: 0,
  headlessHouseNet: 0,
  headlessTotalWagered: 0,
  headlessAvgBet: 0,
  headlessEdgePct: 0,
  headlessBroke: false,
  headlessStats: emptyHeadlessStats(),
};

// Normalisation safety
function normalize(state: State): State {
  const dedupeHand = (hand: Card[]) => {
    const seen = new Set<string>();
    const out: Card[] = [];
    for (const c of hand) {
      if (seen.has(c.id)) continue;
      seen.add(c.id);
      out.push(c);
    }
    return out;
  };

  const p = dedupeHand(state.playerHand);
  const d = dedupeHand(state.dealerHand);

  const inPlay = new Set<string>();
  for (const c of p) inPlay.add(c.id);
  for (const c of d) inPlay.add(c.id);

  let deckOk = !hasDuplicatesById(state.deck);
  if (deckOk) {
    for (const c of state.deck) {
      if (inPlay.has(c.id)) {
        deckOk = false;
        break;
      }
    }
  }

  const deck = deckOk ? state.deck : shuffle(buildDeck().filter((c) => !inPlay.has(c.id)));

  const handsChanged = p.length !== state.playerHand.length || d.length !== state.dealerHand.length;
  const deckChanged = deck !== state.deck;

  if (!handsChanged && !deckChanged) return state;
  return { ...state, playerHand: p, dealerHand: d, deck };
}

function assertState(state: State) {
  if (process.env.NODE_ENV === "production") return;

  if (!Number.isInteger(state.bet)) throw new Error(`BET NOT INTEGER: ${state.bet}`);
  if (state.bet < 0 || state.bet > MAX_BET) throw new Error(`BET OUT OF RANGE: ${state.bet}`);

  const seen = new Set<string>();
  for (const c of state.playerHand) {
    if (seen.has(c.id)) throw new Error(`DUPLICATE IN PLAYER HAND: ${c.id}`);
    seen.add(c.id);
  }
  for (const c of state.dealerHand) {
    if (seen.has(c.id)) throw new Error(`OVERLAP PLAYER/DEALER: ${c.id}`);
    seen.add(c.id);
  }
  if (hasDuplicatesById(state.deck)) throw new Error("DUPLICATE IN DECK");
  for (const c of state.deck) {
    if (seen.has(c.id)) throw new Error(`DECK COLLIDES WITH IN-PLAY: ${c.id}`);
  }

  const pTot = handTotal(state.playerHand);
  if (state.phase === "PLAYER" && pTot > BUST && !state.playerInitialBust) {
    throw new Error(`ILLEGAL STATE: PLAYER PHASE WITH HIT-BUST TOTAL ${pTot}`);
  }

  if (state.playerInitialBust) {
    if (state.playerHand.length !== 2) throw new Error("INITIAL BUST FLAG SET BUT PLAYER HAND NOT 2 CARDS");
    if (handTotal(state.playerHand) <= BUST) throw new Error("INITIAL BUST FLAG SET BUT PLAYER TOTAL NOT > BUST");
  }

  if (state.keyHeld && state.keyActive) throw new Error("ILLEGAL KEY STATE: keyHeld and keyActive both true");
  if (state.keyHeld && state.keyHeldTtl <= 0) throw new Error("ILLEGAL KEY STATE: keyHeld true but ttl <= 0");
  if (state.keyActiveWaitHands < 0) throw new Error("ILLEGAL KEY WAIT HANDS < 0");
}

function winBonus(bet: number) {
  return Math.floor(Math.trunc(bet) * PLAYER_WIN_BONUS_PCT);
}

function countSevens(hand: Card[]) {
  return hand.reduce((n, c) => n + (c.value === 7 ? 1 : 0), 0);
}

function uniqueSuitCount(hand: Card[]) {
  const s = new Set<Suit>();
  for (const c of hand) s.add(c.suit);
  return s.size;
}

function maxSameSuitCount(hand: Card[]) {
  const m: Record<string, number> = {};
  for (const c of hand) m[c.suit] = (m[c.suit] || 0) + 1;
  let best = 0;
  for (const k of Object.keys(m)) best = Math.max(best, m[k]);
  return best;
}

function hasRunOfLength(hand: Card[], len: number) {
  if (hand.length < len) return false;
  const vals = hand.map((c) => c.value);
  for (let i = 0; i <= vals.length - len; i++) {
    let ok = true;
    for (let j = 1; j < len; j++) {
      if (vals[i + j] !== vals[i] + j) {
        ok = false;
        break;
      }
    }
    if (ok) return true;
  }
  return false;
}

// Tick HELD TTL only. ACTIVE does not expire.
function tickKeyHeldTTLAtResolve(state: State): { keyHeld: boolean; keyHeldTtl: number; expiredHeld: boolean } {
  let expiredHeld = false;
  let keyHeld = state.keyHeld;
  let keyHeldTtl = state.keyHeldTtl;

  if (keyHeld) {
    keyHeldTtl = Math.max(0, Math.trunc(keyHeldTtl) - 1);
    if (keyHeldTtl === 0) {
      keyHeld = false;
      expiredHeld = true;
    }
  }

  return { keyHeld, keyHeldTtl, expiredHeld };
}

function reducer(state0: State, action: Action): State {
  let state = normalize(state0);

  // Helper: resolve an immediate hit-bust (player bust caused by DRAW) as a fully accounted hand
  const resolveHitBust = (deckAfter: Card[], playerHandAfter: Card[], bustTotal: number): State => {
    const nextHandIndex = state.handIndex + 1;

    let jackpotPot = Math.trunc(state.jackpotPot + JACKPOT_CONTRIB_PER_HAND);

    const sevens = countSevens(playerHandAfter);
    const triple7Hit = sevens >= 3;
    const triple7Paid = triple7Hit ? Math.trunc(state.bet * TRIPLE7_EXTRA_MULT) : 0;

    const heldTick = tickKeyHeldTTLAtResolve(state);

    // baseEligible window
    const is21stHand = nextHandIndex % JACKPOT_HAND_MOD === 0;
    const baseEligible = is21stHand && state.made1717ViaDraw && eq2(bustTotal, JACKPOT_TRIGGER_TOTAL);

    // keyEligible
    const keyEligible = baseEligible && state.keyActive;

    // microroll
    const microPass = keyEligible ? randFloat01() < JACKPOT_MICROROLL_P : false;
    const jackpotHit = microPass;

    let jackpotPaid = 0;
    if (jackpotHit) {
      jackpotPaid = jackpotPot;
      jackpotPot = JACKPOT_BASE_POT;
    }

    // Consume ACTIVE key when the base window occurs (hit or miss)
    const keyConsumedNow = keyEligible;
    const nextKeyActive = keyConsumedNow ? false : state.keyActive;
    const nextKeyWait = keyConsumedNow ? 0 : nextKeyActive ? state.keyActiveWaitHands + 1 : 0;

    let bankrollDelta = -state.bet;
    const msgParts: string[] = [`You bust (${bustTotal.toFixed(2)}). You lose. (-${state.bet} sats)`];

    if (triple7Paid > 0) {
      bankrollDelta += triple7Paid;
      msgParts.push(`TRIPLE-7 bonus: (+${triple7Paid} sats)`);
    }
    if (jackpotPaid > 0) {
      bankrollDelta += jackpotPaid;
      msgParts.push(`JACKPOT HIT (hand ${nextHandIndex}, total ${JACKPOT_TRIGGER_TOTAL.toFixed(2)}): (+${jackpotPaid} sats)`);
    }
    if (keyConsumedNow) {
      msgParts.push("KEY CONSUMED (base window passed)");
    }
    if (heldTick.expiredHeld) {
      msgParts.push("KEY EXPIRED (held TTL)");
    }

    const next: State = {
      ...state,
      phase: "DONE",
      deck: deckAfter,
      playerHand: playerHandAfter,
      bankroll: state.bankroll + bankrollDelta,
      jackpotPot,
      handIndex: nextHandIndex,
      streakWins: 0,
      message: msgParts.join(" "),

      keyHeld: heldTick.keyHeld,
      keyHeldTtl: heldTick.keyHeldTtl,
      keyActive: nextKeyActive,
      keyActiveWaitHands: nextKeyWait,
      keyActivatedPending: false, // resolved hand writes this into `last` and clears

      last: {
        outcome: "LOSS",
        bonusWinPaid: 0,
        triple7Paid,
        seventhHandPaid: 0,
        jackpotPaid,
        jackpotBaseEligible: baseEligible,
        jackpotKeyEligible: keyEligible,
        jackpotMicroPass: microPass,
        keyEarned: false,
        keyActivated: state.keyActivatedPending,
        keyConsumed: keyConsumedNow,
        keyExpiredHeld: heldTick.expiredHeld,
      },
    };

    assertState(next);
    return next;
  };

  switch (action.type) {
    case "RESET_RUN": {
      const next: State = {
        ...initialState,
        seed: cryptoSeed32(),
        deck: shuffle(buildDeck()),
        jackpotPot: JACKPOT_BASE_POT,
        message: "Place a bet to join the table.",
      };
      assertState(next);
      return next;
    }

    case "SHUFFLE": {
      const inPlay = new Set<string>();
      for (const c of state.playerHand) inPlay.add(c.id);
      for (const c of state.dealerHand) inPlay.add(c.id);

      const safeDeck = buildDeck().filter((c) => !inPlay.has(c.id));
      const next: State = {
        ...state,
        seed: cryptoSeed32(),
        deck: shuffle(safeDeck),
        message:
          state.phase === "PLAYER"
            ? state.playerInitialBust
              ? "You were dealt bust. Press STAND."
              : "Your turn. Draw 2, Draw 1, or Stand."
            : state.phase === "LOBBY"
            ? "Place a bet to join the table."
            : state.message,
      };
      assertState(next);
      return next;
    }

    case "RESET_BET": {
      if (state.phase !== "LOBBY") return state;
      const next: State = { ...state, bet: 0, message: "Place a bet to join the table." };
      assertState(next);
      return next;
    }

    case "BET_ADD": {
      if (state.phase !== "LOBBY") return state;
      const nextBet = clampBet(state.bet + Math.trunc(action.inc));
      const next: State = {
        ...state,
        bet: nextBet,
        message: nextBet > 0 ? "Bet set. Press START to deal." : "Place a bet to join the table.",
      };
      assertState(next);
      return next;
    }

    case "BET_PLACE_CTA": {
      if (state.phase !== "LOBBY") return state;
      const nextBet = state.bet > 0 ? state.bet : 10;
      const next: State = { ...state, bet: clampBet(nextBet), message: "Bet set. Press START to deal." };
      assertState(next);
      return next;
    }

    case "ACTIVATE_KEY": {
      if (state.phase !== "LOBBY") return state;
      if (!state.keyHeld) return state;

      const next: State = {
        ...state,
        keyHeld: false,
        keyHeldTtl: 0,
        keyActive: true,
        keyActiveWaitHands: 0,
        keyActivatedPending: true,
        message: "Key activated. It will wait for the next base-eligible window.",
      };
      assertState(next);
      return next;
    }

    case "START": {
      if (state.phase !== "LOBBY") return state;
      if (state.bet <= 0) return { ...state, message: "You must place a bet first." };
      if (state.bet > state.bankroll) return { ...state, message: "Bet exceeds bankroll." };

      let deckToUse = state.deck;
      let seed = state.seed;
      if (deckToUse.length < AUTO_SHUFFLE_BEFORE_DEAL_IF_DECK_LT) {
        seed = cryptoSeed32();
        deckToUse = shuffle(buildDeck());
      }

      const inPlay = new Set<string>();
      const { taken, rest } = takeUnique(deckToUse, 4, inPlay);

      const p = [taken[0], taken[2]];
      const d = [taken[1], taken[3]];
      const pTot = handTotal(p);
      const initBust = pTot > BUST;

      const next: State = {
        ...state,
        seed,
        phase: "PLAYER",
        deck: rest,
        playerHand: p,
        dealerHand: d,
        playerInitialBust: initBust,
        playerHitThisHand: false,
        made1717ViaDraw: false,
        last: emptyLast(),
        message: initBust ? "You were dealt bust. Press STAND." : "Your turn. Draw 2, Draw 1, or Stand.",
      };
      assertState(next);
      return next;
    }

    case "DRAW": {
      if (state.phase !== "PLAYER") return state;

      if (state.playerInitialBust) {
        return { ...state, message: "You were dealt bust. You can only STAND." };
      }

      const currentP = handTotal(state.playerHand);
      if (currentP > BUST) return state;

      const inPlay = new Set<string>();
      for (const c of state.playerHand) inPlay.add(c.id);
      for (const c of state.dealerHand) inPlay.add(c.id);

      const { taken, rest } = takeUnique(state.deck, action.n, inPlay);
      const nextHand = [...state.playerHand, ...taken];
      const pt = handTotal(nextHand);

      const made1717 = state.made1717ViaDraw || eq2(pt, JACKPOT_TRIGGER_TOTAL);

      const hitMarked: State = {
        ...state,
        deck: rest,
        playerHand: nextHand,
        playerHitThisHand: true,
        made1717ViaDraw: made1717,
      };

      if (pt > BUST) {
        return (() => {
          const prev = state;
          state = hitMarked;
          const out = resolveHitBust(rest, nextHand, pt);
          state = prev;
          return out;
        })();
      }

      const next: State = {
        ...hitMarked,
        message: "Your turn. Draw 2, Draw 1, or Stand.",
      };
      assertState(next);
      return next;
    }

    case "STAND": {
      if (state.phase !== "PLAYER") return state;
      const next: State = { ...state, phase: "DEALER", message: "Dealer plays..." };
      assertState(next);
      return next;
    }

    case "DEALER_PLAY": {
      if (state.phase !== "DEALER") return state;

      let deck = state.deck;
      let dh = [...state.dealerHand];

      const inPlayBase = new Set<string>();
      for (const c of state.playerHand) inPlayBase.add(c.id);
      for (const c of dh) inPlayBase.add(c.id);

      if (dh.length < 2) {
        const { taken, rest } = takeUnique(deck, 2 - dh.length, inPlayBase);
        dh = [...dh, ...taken];
        deck = rest;
      }

      let dt = handTotal(dh);
      while (dt < DEALER_STAND) {
        const inPlay = new Set<string>();
        for (const c of state.playerHand) inPlay.add(c.id);
        for (const c of dh) inPlay.add(c.id);

        const { taken, rest } = takeUnique(deck, 1, inPlay);
        dh = [...dh, taken[0]];
        deck = rest;
        dt = handTotal(dh);
      }

      const pt = handTotal(state.playerHand);
      const dealerBust = dt > BUST;

      const bonusWin = winBonus(state.bet);

      let outcome: "WIN" | "LOSS" | "PUSH" = "PUSH";
      if (state.playerInitialBust) {
        outcome = dealerBust ? "WIN" : "LOSS";
      } else {
        if (pt > BUST) outcome = "LOSS";
        else if (dealerBust) outcome = "WIN";
        else if (pt > dt) outcome = "WIN";
        else if (pt < dt) outcome = "LOSS";
        else outcome = "PUSH";
      }

      const nextHandIndex = state.handIndex + 1;

      let jackpotPot = Math.trunc(state.jackpotPot + JACKPOT_CONTRIB_PER_HAND);

      const heldTick = tickKeyHeldTTLAtResolve(state);

      const is21stHand = nextHandIndex % JACKPOT_HAND_MOD === 0;
      const baseEligible = is21stHand && state.made1717ViaDraw && eq2(pt, JACKPOT_TRIGGER_TOTAL);

      const keyEligible = baseEligible && state.keyActive;
      const microPass = keyEligible ? randFloat01() < JACKPOT_MICROROLL_P : false;
      const jackpotHit = microPass;

      let jackpotPaid = 0;
      if (jackpotHit) {
        jackpotPaid = jackpotPot;
        jackpotPot = JACKPOT_BASE_POT;
      }

      const sevens = countSevens(state.playerHand);
      const triple7Hit = sevens >= 3;
      const triple7Paid = triple7Hit ? Math.trunc(state.bet * TRIPLE7_EXTRA_MULT) : 0;

      const seventhHandWin = outcome === "WIN" && nextHandIndex % 7 === 0;
      const seventhHandPaid = seventhHandWin ? state.bet : 0;

      const canEarnKey = outcome === "WIN" && bonusWin > 0 && !state.keyHeld && !state.keyActive;
      const keyEarnedNow = canEarnKey;

      // Apply HELD tick + earning
      let keyHeld = heldTick.keyHeld;
      let keyHeldTtl = heldTick.keyHeldTtl;

      // ACTIVE persists until baseEligible window, then consumed
      let keyActive = state.keyActive;
      let keyActiveWaitHands = state.keyActiveWaitHands;

      if (keyEarnedNow) {
        keyHeld = true;
        keyHeldTtl = KEY_TTL_HANDS;
      }

      // Consume ACTIVE key when base window occurs
      const keyConsumedNow = keyEligible;
      if (keyConsumedNow) {
        keyActive = false;
        keyActiveWaitHands = 0;
      } else if (keyActive) {
        keyActiveWaitHands = Math.trunc(keyActiveWaitHands) + 1;
      } else {
        keyActiveWaitHands = 0;
      }

      // Enforce single-key invariant
      if (keyActive) {
        keyHeld = false;
        keyHeldTtl = 0;
      }

      let bankrollDelta = 0;
      const msgParts: string[] = [];

      if (outcome === "WIN") {
        const payout = state.bet + bonusWin;
        bankrollDelta += payout;
        msgParts.push(
          state.playerInitialBust
            ? `Dealer busts (${dt.toFixed(2)}). You win. (+${payout} sats)`
            : dealerBust
            ? `Dealer busts (${dt.toFixed(2)}). You win. (+${payout} sats)`
            : `You win. (P ${pt.toFixed(2)} vs D ${dt.toFixed(2)}) (+${payout} sats)`
        );
      } else if (outcome === "LOSS") {
        bankrollDelta -= state.bet;
        msgParts.push(
          state.playerInitialBust
            ? `You were dealt bust (${pt.toFixed(2)}). Dealer stands (${dt.toFixed(2)}). You lose. (-${state.bet} sats)`
            : pt > BUST
            ? `You bust (${pt.toFixed(2)}). You lose. (-${state.bet} sats)`
            : `You lose. (P ${pt.toFixed(2)} vs D ${dt.toFixed(2)}) (-${state.bet} sats)`
        );
      } else {
        msgParts.push(`Push. (P ${pt.toFixed(2)} vs D ${dt.toFixed(2)}) (+0 sats)`);
      }

      if (seventhHandPaid > 0) {
        bankrollDelta += seventhHandPaid;
        msgParts.push(`7th-hand win bonus: (+${seventhHandPaid} sats)`);
      }
      if (triple7Paid > 0) {
        bankrollDelta += triple7Paid;
        msgParts.push(`TRIPLE-7 bonus: (+${triple7Paid} sats)`);
      }
      if (jackpotPaid > 0) {
        bankrollDelta += jackpotPaid;
        msgParts.push(`JACKPOT HIT (hand ${nextHandIndex}, total ${JACKPOT_TRIGGER_TOTAL.toFixed(2)}): (+${jackpotPaid} sats)`);
      }
      if (keyEarnedNow) {
        msgParts.push(`KEY EARNED (held ${KEY_TTL_HANDS} hands)`);
      }
      if (state.keyActivatedPending) {
        msgParts.push("KEY ACTIVATED (waiting for next base window)");
      }
      if (keyConsumedNow) {
        msgParts.push("KEY CONSUMED (base window passed)");
      }
      if (heldTick.expiredHeld) {
        msgParts.push("KEY EXPIRED (held TTL)");
      }

      const nextStreakWins = outcome === "WIN" ? state.streakWins + 1 : 0;
      const nextBankroll = state.bankroll + bankrollDelta;

      const next: State = {
        ...state,
        phase: "DONE",
        deck,
        dealerHand: dh,
        bankroll: nextBankroll,
        jackpotPot,
        handIndex: nextHandIndex,
        streakWins: nextStreakWins,
        message: msgParts.join(" "),

        keyHeld,
        keyHeldTtl,
        keyActive,
        keyActiveWaitHands,
        keyActivatedPending: false,

        last: {
          outcome,
          bonusWinPaid: outcome === "WIN" ? bonusWin : 0,
          triple7Paid,
          seventhHandPaid,
          jackpotPaid,
          jackpotBaseEligible: baseEligible,
          jackpotKeyEligible: keyEligible,
          jackpotMicroPass: microPass,
          keyEarned: keyEarnedNow,
          keyActivated: state.keyActivatedPending,
          keyConsumed: keyConsumedNow,
          keyExpiredHeld: heldTick.expiredHeld,
        },
      };

      assertState(next);
      return next;
    }

    case "NEXT_HAND": {
      if (state.phase !== "DONE") return state;
      const next: State = {
        ...state,
        phase: "LOBBY",
        bet: 0,
        playerHand: [],
        dealerHand: [],
        playerInitialBust: false,
        playerHitThisHand: false,
        made1717ViaDraw: false,
        message: "Place a bet to join the table.",
      };
      assertState(next);
      return next;
    }

    case "HEADLESS_SET_ACTIVE": {
      const next: State = { ...state, headlessActive: action.active };
      assertState(next);
      return next;
    }

    case "HEADLESS_APPLY": {
      const next: State = { ...state, ...action.next };
      assertState(next);
      return next;
    }

    default:
      return state;
  }
}

function safeFilenameStamp(d: Date) {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

function headlessRandomBet(): number {
  const r = (randFloat01() + randFloat01()) / 2;
  const b = 1 + Math.floor(r * MAX_BET);
  const p = randFloat01();
  if (p < 0.12) return 10;
  if (p < 0.20) return 21;
  if (p < 0.24) return 50;
  return clampBet(b);
}

function headlessChooseAction(pTotal: number, dealerUpTotal: number): { type: "STAND" } | { type: "DRAW"; n: 1 | 2 } {
  if (pTotal >= 19.0) return { type: "STAND" };

  const dealerStrong = dealerUpTotal >= 9.0;
  const dealerWeak = dealerUpTotal <= 6.0;

  if (pTotal < 7.0) {
    const p2 = dealerStrong ? 0.75 : 0.60;
    return randFloat01() < p2 ? { type: "DRAW", n: 2 } : { type: "DRAW", n: 1 };
  }

  if (pTotal >= 17.0 && pTotal < 18.0) {
    const standP = dealerStrong ? 0.55 : dealerWeak ? 0.80 : 0.70;
    return randFloat01() < standP ? { type: "STAND" } : { type: "DRAW", n: 1 };
  }

  if (pTotal >= 18.0 && pTotal < 19.0) {
    const standP = dealerStrong ? 0.70 : 0.90;
    return randFloat01() < standP ? { type: "STAND" } : { type: "DRAW", n: 1 };
  }

  if (pTotal >= 16.0) {
    if (dealerStrong) return randFloat01() < 0.80 ? { type: "DRAW", n: 1 } : { type: "STAND" };
    if (dealerWeak) return randFloat01() < 0.80 ? { type: "STAND" } : { type: "DRAW", n: 1 };
    return randFloat01() < 0.55 ? { type: "DRAW", n: 1 } : { type: "STAND" };
  }

  if (pTotal >= 15.0) {
    if (dealerStrong) return randFloat01() < 0.85 ? { type: "DRAW", n: 1 } : { type: "STAND" };
    if (dealerWeak) return randFloat01() < 0.65 ? { type: "STAND" } : { type: "DRAW", n: 1 };
    return randFloat01() < 0.70 ? { type: "DRAW", n: 1 } : { type: "STAND" };
  }

  if (pTotal >= 14.0) {
    if (dealerWeak) return randFloat01() < 0.35 ? { type: "STAND" } : { type: "DRAW", n: 1 };
    return { type: "DRAW", n: 1 };
  }

  return { type: "DRAW", n: 1 };
}

function simulateOneHand(base: State, bet: number): { afterLobby: State; bankrollDelta: number; derived: any } {
  let s: State = base;
  const betClamped = clampBet(bet);

  // Headless activation decision before the deal
  if (s.phase === "LOBBY" && s.keyHeld && !s.keyActive) {
    if (randFloat01() < KEY_HEADLESS_ACTIVATE_P) {
      s = reducer(s, { type: "ACTIVATE_KEY" });
    }
  }

  const uiBankroll = base.bankroll;

  s = {
    ...s,
    phase: "LOBBY",
    bet: betClamped,
    bankroll: HEADLESS_INFINITE_BANKROLL,
  };

  const simBefore = s.bankroll;

  s = reducer(s, { type: "START" });

  if (s.phase === "LOBBY") {
    const afterLobby: State = {
      ...base,
      phase: "LOBBY",
      bet: 0,
      playerHand: [],
      dealerHand: [],
      playerInitialBust: false,
      playerHitThisHand: false,
      made1717ViaDraw: false,
      message: "Place a bet to join the table.",
    };
    return { afterLobby, bankrollDelta: 0, derived: {} };
  }

  while (s.phase === "PLAYER") {
    if (s.playerInitialBust) {
      s = reducer(s, { type: "STAND" });
      break;
    }

    const pTot = handTotal(s.playerHand);
    const dealerUp = s.dealerHand[0] ?? null;
    const dealerUpTot = dealerUp ? round2(cardScore(dealerUp)) : 0;

    if (pTot > BUST) break;

    const a = headlessChooseAction(pTot, dealerUpTot);
    s = a.type === "STAND" ? reducer(s, { type: "STAND" }) : reducer(s, { type: "DRAW", n: a.n });
  }

  if (s.phase === "DEALER") {
    s = reducer(s, { type: "DEALER_PLAY" });
  }

  const simAfter = s.bankroll;
  const bankrollDelta = simAfter - simBefore;

  const playerHand = s.playerHand;
  const playerCards = playerHand.length;

  const maxSuit = maxSameSuitCount(playerHand);
  const uniqSuits = uniqueSuitCount(playerHand);
  const run3 = hasRunOfLength(playerHand, 3);
  const run4 = hasRunOfLength(playerHand, 4);

  const tot = handTotal(playerHand);
  const sevens = countSevens(playerHand);

  const derived = {
    playerCards,
    maxSuit,
    uniqSuits,
    run3,
    run4,
    tot,
    sevens,
    bankrollDelta,
    message: s.message,
    last: s.last,
  };

  if (s.phase === "DONE") {
    s = reducer(s, { type: "NEXT_HAND" });
  } else {
    s = {
      ...s,
      phase: "LOBBY",
      bet: 0,
      playerHand: [],
      dealerHand: [],
      playerInitialBust: false,
      playerHitThisHand: false,
      made1717ViaDraw: false,
      message: "Place a bet to join the table.",
    };
  }

  s = { ...s, bankroll: uiBankroll };

  return { afterLobby: s, bankrollDelta, derived };
}

export default function Home() {
  const [state, dispatch] = useReducer(reducer, initialState);

  const [headlessInput, setHeadlessInput] = useState<string>(state.headlessTargetHands);
  const cancelRef = useRef<boolean>(false);

  useEffect(() => {
    if (state.phase === "DEALER") {
      dispatch({ type: "DEALER_PLAY" });
    }
  }, [state.phase]);

  const playerTotal = useMemo(() => handTotal(state.playerHand), [state.playerHand]);
  const dealerTotal = useMemo(() => handTotal(state.dealerHand), [state.dealerHand]);

  const showDealerDown = state.phase === "DEALER" || state.phase === "DONE";
  const dealerUp = state.dealerHand[0] ?? null;
  const dealerDown = state.dealerHand[1] ?? null;

  const dealerUpTotal = useMemo(() => (dealerUp ? round2(cardScore(dealerUp)) : 0), [dealerUp]);

  const dealerBig = useMemo(() => {
    if (!dealerUp) return "0.00";
    return showDealerDown ? dealerTotal.toFixed(2) : dealerUpTotal.toFixed(2);
  }, [dealerUp, dealerTotal, dealerUpTotal, showDealerDown]);

  const dealerTitle = showDealerDown ? "DEALER TOTAL" : "DEALER UP-CARD TOTAL";

  const canBet = state.phase === "LOBBY" && !state.headlessActive;
  const canStart = state.phase === "LOBBY" && state.bet > 0 && state.bet <= state.bankroll && !state.headlessActive;

  const canDraw = state.phase === "PLAYER" && !state.playerInitialBust && playerTotal <= BUST && !state.headlessActive;
  const canStand = state.phase === "PLAYER" && (state.playerInitialBust || playerTotal <= BUST) && !state.headlessActive;

  const canNextHand = state.phase === "DONE" && !state.headlessActive;

  const dealerCardsToRender: Array<{ key: string; card: Card | null; hiddenSlot?: boolean }> = useMemo(() => {
    if (state.dealerHand.length === 0) return [];
    const list: Array<{ key: string; card: Card | null; hiddenSlot?: boolean }> = [];

    if (dealerUp) list.push({ key: `up-${dealerUp.id}`, card: dealerUp });

    if (showDealerDown) {
      if (dealerDown) list.push({ key: `down-${dealerDown.id}`, card: dealerDown });
      for (let i = 2; i < state.dealerHand.length; i++) {
        const c = state.dealerHand[i];
        list.push({ key: `ex-${c.id}-${i}`, card: c });
      }
    } else {
      list.push({ key: "down-hidden", card: null, hiddenSlot: true });
    }
    return list;
  }, [state.dealerHand, dealerUp, dealerDown, showDealerDown]);

  const parseBigIntSafe = (s: string): bigint => {
    const t = s.trim();
    if (t === "") return 0n;
    const cleaned = t.replace(/[^\d]/g, "");
    if (cleaned === "") return 0n;
    try {
      return BigInt(cleaned);
    } catch {
      return 0n;
    }
  };

  const startHeadless = useCallback(() => {
    if (state.headlessActive) return;

    const target = parseBigIntSafe(headlessInput);
    if (target <= 0n) {
      dispatch({
        type: "HEADLESS_APPLY",
        next: {
          seed: state.seed,
          phase: state.phase,
          deck: state.deck,
          playerHand: state.playerHand,
          dealerHand: state.dealerHand,
          bankroll: state.bankroll,
          bet: state.bet,
          casinoBank: state.casinoBank,
          jackpotPot: state.jackpotPot,
          handIndex: state.handIndex,
          streakWins: state.streakWins,
          last7Bets: state.last7Bets,
          message: "Headless target hands must be >= 1.",
          playerInitialBust: state.playerInitialBust,
          playerHitThisHand: state.playerHitThisHand,
          made1717ViaDraw: state.made1717ViaDraw,
          keyHeld: state.keyHeld,
          keyHeldTtl: state.keyHeldTtl,
          keyActive: state.keyActive,
          keyActiveWaitHands: state.keyActiveWaitHands,
          keyActivatedPending: state.keyActivatedPending,
          last: state.last,
          headlessActive: false,
          headlessTargetHands: headlessInput.trim() === "" ? "0" : headlessInput,
          headlessHandsDone: 0,
          headlessHouseNet: 0,
          headlessTotalWagered: 0,
          headlessAvgBet: 0,
          headlessEdgePct: 0,
          headlessBroke: false,
          headlessStats: emptyHeadlessStats(),
        },
      });
      return;
    }

    cancelRef.current = false;
    dispatch({ type: "HEADLESS_SET_ACTIVE", active: true });

    const startCasino = HEADLESS_CASINO_BANK_START;

    let stats = emptyHeadlessStats();

    let sim: State = {
      ...state,
      phase: "LOBBY",
      bet: 0,
      playerHand: [],
      dealerHand: [],
      playerInitialBust: false,
      playerHitThisHand: false,
      made1717ViaDraw: false,

      keyHeld: false,
      keyHeldTtl: 0,
      keyActive: false,
      keyActiveWaitHands: 0,
      keyActivatedPending: false,

      last: emptyLast(),

      casinoBank: startCasino,
      jackpotPot: JACKPOT_BASE_POT,

      handIndex: 0,
      streakWins: 0,
      last7Bets: [],

      headlessActive: true,
      headlessTargetHands: target.toString(),
      headlessHandsDone: 0,
      headlessHouseNet: 0,
      headlessTotalWagered: 0,
      headlessAvgBet: 0,
      headlessEdgePct: 0,
      headlessBroke: false,
      headlessStats: stats,

      message: "Headless running...",
    };

    let remaining = target;
    let done = 0;
    let casinoBank = startCasino;
    let totalWagered = 0;

    const tick = () => {
      if (cancelRef.current) {
        const net = casinoBank - startCasino;
        const avgBet = done > 0 ? totalWagered / done : 0;
        const edgePct = totalWagered > 0 ? (net / totalWagered) * 100 : 0;

        dispatch({
          type: "HEADLESS_APPLY",
          next: {
            seed: sim.seed,
            phase: "LOBBY",
            deck: sim.deck,
            playerHand: [],
            dealerHand: [],
            bankroll: state.bankroll,
            bet: 0,
            casinoBank,
            jackpotPot: sim.jackpotPot,
            handIndex: sim.handIndex,
            streakWins: sim.streakWins,
            last7Bets: sim.last7Bets,
            message: `Headless stopped: ${done} hands. House net: ${net} sats. Wagered: ${totalWagered} sats. Edge: ${edgePct.toFixed(4)}%.`,
            playerInitialBust: false,
            playerHitThisHand: false,
            made1717ViaDraw: false,
            keyHeld: sim.keyHeld,
            keyHeldTtl: sim.keyHeldTtl,
            keyActive: sim.keyActive,
            keyActiveWaitHands: sim.keyActiveWaitHands,
            keyActivatedPending: false,
            last: sim.last,
            headlessActive: false,
            headlessTargetHands: target.toString(),
            headlessHandsDone: done,
            headlessHouseNet: net,
            headlessTotalWagered: totalWagered,
            headlessAvgBet: avgBet,
            headlessEdgePct: edgePct,
            headlessBroke: casinoBank < 0,
            headlessStats: stats,
          },
        });
        return;
      }

      const chunk = remaining > BigInt(HEADLESS_CHUNK_HANDS) ? HEADLESS_CHUNK_HANDS : Number(remaining);

      for (let i = 0; i < chunk; i++) {
        const bet = headlessRandomBet();
        totalWagered += bet;

        const last7 = [...sim.last7Bets, bet].slice(-7);

        const { afterLobby, bankrollDelta, derived } = simulateOneHand(sim, bet);

        casinoBank = Math.trunc(casinoBank - bankrollDelta);
        done++;

        const last: LastHandFlags = derived?.last || emptyLast();

        if (last.outcome === "WIN") stats.wins++;
        else if (last.outcome === "LOSS") stats.losses++;
        else if (last.outcome === "PUSH") stats.pushes++;

        const pc: number = derived?.playerCards ?? 0;
        if (pc === 2) stats.playerFinalCards_2++;
        else if (pc === 3) stats.playerFinalCards_3++;
        else if (pc === 4) stats.playerFinalCards_4++;
        else if (pc === 5) stats.playerFinalCards_5++;
        else if (pc === 6) stats.playerFinalCards_6++;
        else if (pc >= 7) stats.playerFinalCards_7p++;

        const maxSuit: number = derived?.maxSuit ?? 0;
        if (maxSuit >= 4) stats.freq4SameSuit++;
        if (maxSuit >= 5) stats.freq5SameSuit++;

        if (derived?.run3) stats.freq3Run++;
        if (derived?.run4) stats.freq4Run++;

        const us: number = derived?.uniqSuits ?? 0;
        if (us === 4) stats.uniqSuits4++;
        if (us === 5) stats.uniqSuits5++;
        if (us === 6) stats.uniqSuits6++;
        if (us === 7) stats.uniqSuits7++;

        const tot: number = derived?.tot ?? 0;
        if (eq2(tot, 21.0)) stats.exact21++;
        if (eq2(tot, 17.17)) stats.exact1717++;

        const sevens: number = derived?.sevens ?? 0;
        if (sevens >= 1) stats.handsWith7++;
        if (sevens >= 2) stats.handsWith2x7++;
        if (sevens >= 3) stats.handsWith3x7++;
        stats.total7CardsDealtToPlayer += sevens;

        if (last.bonusWinPaid > 0) stats.bonusPaidWinBonus += last.bonusWinPaid;
        if (last.triple7Paid > 0) stats.bonusPaidTriple7 += last.triple7Paid;
        if (last.seventhHandPaid > 0) stats.bonusPaidSeventhHand += last.seventhHandPaid;

        stats.jackpotContribTotal += JACKPOT_CONTRIB_PER_HAND;
        if (last.jackpotPaid > 0) {
          stats.jackpotHits += 1;
          stats.jackpotPaidTotal += last.jackpotPaid;
        }

        if (last.jackpotBaseEligible) stats.jackpotBaseEligible += 1;
        if (last.jackpotKeyEligible) stats.jackpotKeyEligible += 1;
        if (last.jackpotMicroPass) stats.jackpotMicroPass += 1;

        if (last.keyEarned) stats.keyEarned += 1;
        if (last.keyActivated) stats.keyActivated += 1;
        if (last.keyConsumed) stats.keyConsumed += 1;
        if (last.keyExpiredHeld) stats.keyExpiredHeld += 1;

        sim = {
          ...afterLobby,
          casinoBank,
          jackpotPot: afterLobby.jackpotPot,
          handIndex: afterLobby.handIndex,
          streakWins: afterLobby.streakWins,
          last7Bets: last7,
          headlessActive: true,
          headlessStats: stats,
          last: afterLobby.last,
        };

        if (casinoBank < 0) {
          remaining = 0n;
          break;
        }
      }

      remaining = remaining - BigInt(chunk);

      const net = casinoBank - startCasino;
      const avgBet = done > 0 ? totalWagered / done : 0;
      const edgePct = totalWagered > 0 ? (net / totalWagered) * 100 : 0;

      dispatch({
        type: "HEADLESS_APPLY",
        next: {
          seed: sim.seed,
          phase: "LOBBY",
          deck: sim.deck,
          playerHand: [],
          dealerHand: [],
          bankroll: state.bankroll,
          bet: 0,
          casinoBank,
          jackpotPot: sim.jackpotPot,
          handIndex: sim.handIndex,
          streakWins: sim.streakWins,
          last7Bets: sim.last7Bets,
          message: `Headless running: ${done} / ${target.toString()} hands...`,
          playerInitialBust: false,
          playerHitThisHand: false,
          made1717ViaDraw: false,
          keyHeld: sim.keyHeld,
          keyHeldTtl: sim.keyHeldTtl,
          keyActive: sim.keyActive,
          keyActiveWaitHands: sim.keyActiveWaitHands,
          keyActivatedPending: false,
          last: sim.last,
          headlessActive: true,
          headlessTargetHands: target.toString(),
          headlessHandsDone: done,
          headlessHouseNet: net,
          headlessTotalWagered: totalWagered,
          headlessAvgBet: avgBet,
          headlessEdgePct: edgePct,
          headlessBroke: casinoBank < 0,
          headlessStats: stats,
        },
      });

      if (remaining > 0n && casinoBank >= 0) {
        setTimeout(tick, 0);
        return;
      }

      dispatch({
        type: "HEADLESS_APPLY",
        next: {
          seed: sim.seed,
          phase: "LOBBY",
          deck: sim.deck,
          playerHand: [],
          dealerHand: [],
          bankroll: state.bankroll,
          bet: 0,
          casinoBank,
          jackpotPot: sim.jackpotPot,
          handIndex: sim.handIndex,
          streakWins: sim.streakWins,
          last7Bets: sim.last7Bets,
          message: `Headless complete: ${done} hands. House net: ${net} sats. Wagered: ${totalWagered} sats. Edge: ${edgePct.toFixed(4)}%.`,
          playerInitialBust: false,
          playerHitThisHand: false,
          made1717ViaDraw: false,
          keyHeld: sim.keyHeld,
          keyHeldTtl: sim.keyHeldTtl,
          keyActive: sim.keyActive,
          keyActiveWaitHands: sim.keyActiveWaitHands,
          keyActivatedPending: false,
          last: sim.last,
          headlessActive: false,
          headlessTargetHands: target.toString(),
          headlessHandsDone: done,
          headlessHouseNet: net,
          headlessTotalWagered: totalWagered,
          headlessAvgBet: avgBet,
          headlessEdgePct: edgePct,
          headlessBroke: casinoBank < 0,
          headlessStats: stats,
        },
      });
    };

    setTimeout(tick, 0);
  }, [headlessInput, state]);

  const stopHeadless = useCallback(() => {
    cancelRef.current = true;
  }, []);

  const downloadRunDebug = useCallback(() => {
    const now = new Date();
    const stamp = safeFilenameStamp(now);

    const payload: any = {
      version: "p77-beta",
      createdAt: now.toISOString(),
      config: {
        KEY_TTL_HANDS,
        KEY_HEADLESS_ACTIVATE_P,
        JACKPOT_MICROROLL_P,
        PLAYER_WIN_BONUS_PCT,
      },
      state: {
        seed: state.seed,
        phase: state.phase,
        deckCount: state.deck.length,
        bankroll: state.bankroll,
        casinoBank: state.casinoBank,
        jackpotPot: state.jackpotPot,
        bet: state.bet,
        playerInitialBust: state.playerInitialBust,
        playerHitThisHand: state.playerHitThisHand,
        made1717ViaDraw: state.made1717ViaDraw,
        keyHeld: state.keyHeld,
        keyHeldTtl: state.keyHeldTtl,
        keyActive: state.keyActive,
        keyActiveWaitHands: state.keyActiveWaitHands,
        keyActivatedPending: state.keyActivatedPending,
        handIndex: state.handIndex,
        streakWins: state.streakWins,
        last7Bets: state.last7Bets,
        playerTotal: playerTotal,
        dealerTotal: dealerTotal,
        headlessActive: state.headlessActive,
        headlessTargetHands: state.headlessTargetHands,
        headlessHandsDone: state.headlessHandsDone,
        headlessHouseNet: state.headlessHouseNet,
        headlessTotalWagered: state.headlessTotalWagered,
        headlessAvgBet: state.headlessAvgBet,
        headlessEdgePct: state.headlessEdgePct,
        headlessBroke: state.headlessBroke,
        playerHand: state.playerHand.map((c) => c.id),
        dealerHand: state.dealerHand.map((c) => c.id),
        message: state.message,
      },
      last: state.last,
      headlessStats: state.headlessStats,
      cards: {
        playerHand: state.playerHand,
        dealerHand: state.dealerHand,
      },
    };

    const report =
      "PROTOCOL 77 - RUN DEBUG\n" +
      `createdAt: ${payload.createdAt}\n` +
      `version: ${payload.version}\n` +
      `KEY_TTL_HANDS: ${payload.config.KEY_TTL_HANDS}\n` +
      `KEY_HEADLESS_ACTIVATE_P: ${payload.config.KEY_HEADLESS_ACTIVATE_P}\n` +
      `JACKPOT_MICROROLL_P: ${payload.config.JACKPOT_MICROROLL_P}\n` +
      `PLAYER_WIN_BONUS_PCT: ${payload.config.PLAYER_WIN_BONUS_PCT}\n\n` +
      "STATE\n" +
      `seed: ${payload.state.seed}\n` +
      `phase: ${payload.state.phase}\n` +
      `deckCount: ${payload.state.deckCount}\n` +
      `bankroll: ${payload.state.bankroll}\n` +
      `casinoBank: ${payload.state.casinoBank}\n` +
      `jackpotPot: ${payload.state.jackpotPot}\n` +
      `bet: ${payload.state.bet}\n` +
      `playerInitialBust: ${payload.state.playerInitialBust}\n` +
      `playerHitThisHand: ${payload.state.playerHitThisHand}\n` +
      `made1717ViaDraw: ${payload.state.made1717ViaDraw}\n` +
      `keyHeld: ${payload.state.keyHeld}\n` +
      `keyHeldTtl: ${payload.state.keyHeldTtl}\n` +
      `keyActive: ${payload.state.keyActive}\n` +
      `keyActiveWaitHands: ${payload.state.keyActiveWaitHands}\n` +
      `keyActivatedPending: ${payload.state.keyActivatedPending}\n` +
      `handIndex: ${payload.state.handIndex}\n` +
      `streakWins: ${payload.state.streakWins}\n` +
      `last7Bets: ${Array.isArray(payload.state.last7Bets) ? payload.state.last7Bets.join(", ") : ""}\n` +
      `playerTotal: ${Number(payload.state.playerTotal).toFixed(2)}\n` +
      `dealerTotal: ${Number(payload.state.dealerTotal).toFixed(2)}\n` +
      `headlessActive: ${payload.state.headlessActive}\n` +
      `headlessTargetHands: ${payload.state.headlessTargetHands}\n` +
      `headlessHandsDone: ${payload.state.headlessHandsDone}\n` +
      `headlessHouseNet: ${payload.state.headlessHouseNet}\n` +
      `headlessTotalWagered: ${payload.state.headlessTotalWagered}\n` +
      `headlessAvgBet: ${Number(payload.state.headlessAvgBet).toFixed(4)}\n` +
      `headlessEdgePct: ${Number(payload.state.headlessEdgePct).toFixed(6)}\n` +
      `headlessBroke: ${payload.state.headlessBroke}\n` +
      `playerHandIds: ${payload.state.playerHand.join(", ")}\n` +
      `dealerHandIds: ${payload.state.dealerHand.join(", ")}\n` +
      `message: ${payload.state.message}\n\n` +
      "LAST HAND FLAGS\n" +
      JSON.stringify(payload.last, null, 2) +
      "\n\n" +
      "HEADLESS STATS\n" +
      JSON.stringify(payload.headlessStats, null, 2) +
      "\n\n" +
      "JSON\n" +
      JSON.stringify(payload, null, 2) +
      "\n";

    const blob = new Blob([report], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = `protocol77-run-debug-${stamp}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();

    URL.revokeObjectURL(url);
  }, [state, playerTotal, dealerTotal]);

  const safeAvgBet = Number.isFinite(state.headlessAvgBet) ? state.headlessAvgBet : 0;
  const safeEdge = Number.isFinite(state.headlessEdgePct) ? state.headlessEdgePct : 0;

  const canActivateKey = state.phase === "LOBBY" && state.keyHeld && !state.keyActive && !state.headlessActive;

  return (
    <div className="p77">
      <div className="hero">
        <div className="title">PROTOCOL 77 - TABLE</div>
        <div className="sub">PRESS START</div>
        <div className={`status ${state.phase === "DONE" ? "done" : state.phase === "LOBBY" ? "ready" : "live"}`}>
          STATUS: {state.phase === "LOBBY" ? "READY" : state.phase === "DONE" ? "DONE" : "LIVE"}
        </div>

        <div className="panel">
          <div className="chipsRow">
            <div className="chip">Seed: {state.seed}</div>
            <div className="chip">Deck: {state.deck.length}</div>
            <div className="chip">Phase: {state.phase}</div>
            <div className="chip">Bankroll: {state.bankroll} sats</div>
            <div className="chip">Casino bank: {state.casinoBank} sats</div>
            <div className="chip">Jackpot pot: {state.jackpotPot} sats</div>
            <div className="chip">Hand #: {state.handIndex}</div>
            <div className="chip">Win streak: {state.streakWins}</div>
            <div className="chip">
              Bet: {state.bet}
              {state.phase !== "LOBBY" ? " (locked)" : ""}
            </div>
            <div className="chip">
              Key:{" "}
              {state.keyActive
                ? `ACTIVE (waiting ${state.keyActiveWaitHands} hands)`
                : state.keyHeld
                ? `HELD (${state.keyHeldTtl})`
                : "NONE"}
            </div>
          </div>

          <div className="headlessRow">
            <div className="headlessLabel">HEADLESS</div>
            <input
              className="headlessInput"
              value={headlessInput}
              onChange={(e) => setHeadlessInput(e.target.value)}
              disabled={state.headlessActive}
              placeholder="hands"
              inputMode="numeric"
            />
            <button className="btnPrimary" disabled={state.headlessActive} onClick={startHeadless}>
              START HEADLESS
            </button>
            <button className="btnDanger" disabled={!state.headlessActive} onClick={stopHeadless}>
              STOP
            </button>
            <div className="headlessMeta">
              Target: {state.headlessTargetHands} | Done: {state.headlessHandsDone} | Wagered: {state.headlessTotalWagered} | Avg bet:{" "}
              {safeAvgBet.toFixed(4)} | Edge: {safeEdge.toFixed(4)}% | House net: {state.headlessHouseNet} | Broke: {String(state.headlessBroke)}
            </div>
          </div>

          {state.phase === "LOBBY" && state.bet === 0 && (
            <div className="ctaRow">
              <div className="ctaText">Place a bet to join the table.</div>
              <button className="ctaBtn" onClick={() => dispatch({ type: "BET_PLACE_CTA" })} disabled={state.headlessActive}>
                PLACE BET TO JOIN TABLE
              </button>
            </div>
          )}

          <div className="controls">
            <div className="betGroup">
              <div className="label">BET</div>

              <button className="btn" disabled={!canBet || state.bet >= MAX_BET} onClick={() => dispatch({ type: "BET_ADD", inc: 10 })}>
                +10
              </button>
              <button className="btn" disabled={!canBet || state.bet >= MAX_BET} onClick={() => dispatch({ type: "BET_ADD", inc: 21 })}>
                +21
              </button>
              <button className="btn" disabled={!canBet || state.bet >= MAX_BET} onClick={() => dispatch({ type: "BET_ADD", inc: 50 })}>
                +50
              </button>
              <button className="btn" disabled={!canBet || state.bet === 0} onClick={() => dispatch({ type: "RESET_BET" })}>
                RESET BET
              </button>

              <div className="rules">Max bet: {MAX_BET} sats.</div>
            </div>

            <div className="actionGroup">
              <button className="btnPrimary" disabled={!canStart} onClick={() => dispatch({ type: "START" })}>
                START
              </button>
              <button className="btnPrimary" disabled={!canDraw} onClick={() => dispatch({ type: "DRAW", n: 2 })}>
                DRAW 2
              </button>
              <button className="btnPrimary" disabled={!canDraw} onClick={() => dispatch({ type: "DRAW", n: 1 })}>
                DRAW 1
              </button>
              <button className="btnPrimary" disabled={!canStand} onClick={() => dispatch({ type: "STAND" })}>
                STAND
              </button>

              <button className="btnPrimary" disabled={!canActivateKey} onClick={() => dispatch({ type: "ACTIVATE_KEY" })}>
                ACTIVATE KEY
              </button>

              <button className="btn" onClick={() => dispatch({ type: "SHUFFLE" })} disabled={state.headlessActive}>
                SHUFFLE
              </button>

              <button className="btn" onClick={downloadRunDebug}>
                COPY RUN DEBUG
              </button>

              <button className="btn" disabled={!canNextHand} onClick={() => dispatch({ type: "NEXT_HAND" })}>
                NEXT HAND
              </button>

              <button className="btnDanger" onClick={() => dispatch({ type: "RESET_RUN" })} disabled={state.headlessActive}>
                RESET RUN
              </button>
            </div>
          </div>

          <div className="desc">
            77-card core deck (7 suits x 11 values). Bust threshold: {BUST.toFixed(2)}. Dealer stands at {DEALER_STAND.toFixed(0)}+. Player can draw only 2 /
            1. Auto-shuffle before deal if deck &lt; {AUTO_SHUFFLE_BEFORE_DEAL_IF_DECK_LT}. Win bonus pays bet + floor(bet *{" "}
            {PLAYER_WIN_BONUS_PCT.toFixed(4)}). Triple-7 bonus pays +{TRIPLE7_EXTRA_MULT}x bet even if you bust. Jackpot contributes{" "}
            {JACKPOT_CONTRIB_PER_HAND} sat/hand, resets to {JACKPOT_BASE_POT}. Base trigger: every {JACKPOT_HAND_MOD}th resolved hand ends with player total{" "}
            {JACKPOT_TRIGGER_TOTAL.toFixed(2)} achieved via DRAW. Key ACTIVE waits until the next base window, then is consumed. Microroll p=
            {JACKPOT_MICROROLL_P}.
          </div>
        </div>
      </div>

      <div className="msg">{state.message}</div>

      <div className="grid">
        <div className="box">
          <div className="boxTitle">PLAYER TOTAL</div>
          <div className="big">{playerTotal.toFixed(2)}</div>
          <div className="small">Bust at {BUST.toFixed(2)}</div>

          <div className="cards">
            {state.playerHand.length === 0 ? (
              <div className="empty">Place a bet, then press START to deal.</div>
            ) : (
              state.playerHand.map((c, idx) => (
                <div key={`p-${c.id}-${idx}`} className="card">
                  <div className="cardTop">
                    <div className="suit">{c.suit}</div>
                    <div className="val">{c.value}</div>
                  </div>
                  <div className="meta">Rank {c.rank} - Value {c.value}</div>
                  <div className="meta">ID: {c.id}</div>
                  <div className="meta">Card score: {cardScore(c).toFixed(2)}</div>
                  <div className="art">No art yet</div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="box">
          <div className="boxTitle">{dealerTitle}</div>
          <div className="big">{dealerBig}</div>
          <div className="small">{showDealerDown ? "Revealed" : "Up-card shown, down-card hidden"}</div>

          <div className="cards">
            {state.dealerHand.length === 0 ? (
              <div className="empty">Dealer is waiting.</div>
            ) : (
              dealerCardsToRender.map((slot) => {
                if (slot.hiddenSlot) {
                  return (
                    <div key={slot.key} className="card hiddenCard">
                      <div className="cardTop">
                        <div className="suit">Hidden</div>
                        <div className="val">??</div>
                      </div>
                      <div className="meta">Rank ? - Value ?</div>
                      <div className="meta">ID: Hidden</div>
                      <div className="meta">Card score: ??</div>
                      <div className="art">Hidden</div>
                    </div>
                  );
                }

                const c = slot.card!;
                return (
                  <div key={slot.key} className="card">
                    <div className="cardTop">
                      <div className="suit">{c.suit}</div>
                      <div className="val">{c.value}</div>
                    </div>
                    <div className="meta">Rank {c.rank} - Value {c.value}</div>
                    <div className="meta">ID: {c.id}</div>
                    <div className="meta">Card score: {cardScore(c).toFixed(2)}</div>
                    <div className="art">No art yet</div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        .p77 {
          min-height: 100vh;
          color: #e9e9ea;
          background: radial-gradient(60% 50% at 50% 0%, rgba(255, 0, 0, 0.18), rgba(0, 0, 0, 0.95) 60%), #000;
          padding: 36px 22px 60px;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        }
        .hero {
          max-width: 1100px;
          margin: 0 auto;
          text-align: center;
        }
        .title {
          font-size: 56px;
          letter-spacing: 10px;
          color: #ff2b2b;
          text-shadow: 0 0 22px rgba(255, 0, 0, 0.25);
          margin-top: 10px;
        }
        .sub {
          margin-top: 10px;
          letter-spacing: 5px;
          opacity: 0.7;
        }
        .status {
          margin-top: 8px;
          letter-spacing: 3px;
          font-size: 14px;
        }
        .status.live,
        .status.ready {
          color: #37f7c5;
        }
        .status.done {
          color: #ffb3b3;
        }

        .panel {
          margin: 22px auto 10px;
          max-width: 980px;
          border-radius: 22px;
          background: rgba(10, 10, 10, 0.65);
          border: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: 0 0 0 1px rgba(255, 0, 0, 0.12) inset, 0 20px 60px rgba(0, 0, 0, 0.6);
          padding: 18px 18px 14px;
        }
        .chipsRow {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          justify-content: center;
          margin-bottom: 14px;
        }
        .chip {
          padding: 8px 12px;
          border-radius: 999px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: rgba(0, 0, 0, 0.5);
          font-size: 13px;
          opacity: 0.95;
        }

        .headlessRow {
          display: flex;
          gap: 10px;
          justify-content: center;
          align-items: center;
          flex-wrap: wrap;
          padding: 10px 12px;
          margin: 6px 0 14px;
          border-radius: 16px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          background: rgba(0, 0, 0, 0.45);
        }
        .headlessLabel {
          opacity: 0.8;
          letter-spacing: 3px;
          font-size: 13px;
        }
        .headlessInput {
          width: 220px;
          padding: 12px 14px;
          border-radius: 999px;
          border: 1px solid rgba(255, 255, 255, 0.14);
          background: rgba(0, 0, 0, 0.55);
          color: #fff;
          letter-spacing: 1px;
          font-size: 13px;
          outline: none;
        }
        .headlessMeta {
          opacity: 0.7;
          font-size: 12px;
          letter-spacing: 1px;
        }

        .ctaRow {
          display: flex;
          gap: 12px;
          justify-content: center;
          align-items: center;
          padding: 12px;
          margin: 8px 0 14px;
          border-radius: 16px;
          border: 1px solid rgba(255, 0, 0, 0.18);
          background: rgba(0, 0, 0, 0.55);
          box-shadow: 0 0 0 1px rgba(255, 0, 0, 0.06) inset;
          flex-wrap: wrap;
        }
        .ctaText {
          opacity: 0.85;
          letter-spacing: 1px;
        }
        .ctaBtn {
          cursor: pointer;
          padding: 12px 16px;
          border-radius: 999px;
          border: 1px solid rgba(255, 255, 255, 0.16);
          background: rgba(0, 0, 0, 0.75);
          color: #fff;
          letter-spacing: 2px;
          font-size: 13px;
          transition: transform 0.05s ease, border-color 0.15s ease, opacity 0.15s ease;
        }
        .ctaBtn:active {
          transform: translateY(1px);
        }

        .controls {
          display: grid;
          grid-template-columns: 1fr;
          gap: 14px;
        }
        .betGroup,
        .actionGroup {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          justify-content: center;
          align-items: center;
        }
        .label {
          opacity: 0.7;
          letter-spacing: 3px;
          margin-right: 6px;
          font-size: 13px;
        }
        .rules {
          opacity: 0.65;
          font-size: 12px;
          margin-left: 8px;
        }

        .btn,
        .btnPrimary,
        .btnDanger {
          cursor: pointer;
          padding: 12px 16px;
          border-radius: 999px;
          border: 1px solid rgba(255, 255, 255, 0.12);
          background: rgba(0, 0, 0, 0.55);
          color: #fff;
          letter-spacing: 2px;
          font-size: 13px;
          transition: transform 0.05s ease, border-color 0.15s ease, opacity 0.15s ease;
          user-select: none;
        }
        .btnPrimary {
          border-color: rgba(255, 255, 255, 0.18);
          background: rgba(0, 0, 0, 0.7);
        }
        .btnDanger {
          border-color: rgba(255, 50, 50, 0.55);
          box-shadow: 0 0 0 1px rgba(255, 0, 0, 0.15) inset;
        }
        .btn:active,
        .btnPrimary:active,
        .btnDanger:active {
          transform: translateY(1px);
        }
        .btn:disabled,
        .btnPrimary:disabled,
        .btnDanger:disabled {
          opacity: 0.35;
          cursor: not-allowed;
        }

        .desc {
          margin-top: 10px;
          opacity: 0.75;
          font-size: 13px;
          line-height: 1.4;
        }
        .msg {
          max-width: 980px;
          margin: 18px auto 0;
          padding: 14px 16px;
          border-radius: 14px;
          background: rgba(0, 0, 0, 0.65);
          border: 1px solid rgba(255, 0, 0, 0.18);
          box-shadow: 0 0 0 1px rgba(255, 0, 0, 0.08) inset;
          text-align: center;
          letter-spacing: 1px;
        }

        .grid {
          max-width: 1100px;
          margin: 18px auto 0;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 18px;
        }
        @media (max-width: 920px) {
          .grid {
            grid-template-columns: 1fr;
          }
          .title {
            font-size: 40px;
            letter-spacing: 7px;
          }
        }
        .box {
          border-radius: 22px;
          background: rgba(10, 10, 10, 0.6);
          border: 1px solid rgba(255, 255, 255, 0.08);
          padding: 18px;
          box-shadow: 0 18px 50px rgba(0, 0, 0, 0.55);
        }
        .boxTitle {
          opacity: 0.75;
          letter-spacing: 6px;
          font-size: 13px;
          margin-bottom: 10px;
        }
        .big {
          font-size: 56px;
          letter-spacing: 2px;
          margin-bottom: 6px;
        }
        .small {
          opacity: 0.7;
          margin-bottom: 14px;
        }
        .cards {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        @media (max-width: 520px) {
          .cards {
            grid-template-columns: 1fr;
          }
          .big {
            font-size: 46px;
          }
        }
        .card {
          border-radius: 18px;
          background: rgba(0, 0, 0, 0.55);
          border: 1px solid rgba(255, 255, 255, 0.09);
          padding: 14px;
          min-height: 150px;
          position: relative;
          box-shadow: 0 0 0 1px rgba(255, 0, 0, 0.06) inset;
        }
        .cardTop {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          margin-bottom: 10px;
        }
        .suit {
          letter-spacing: 3px;
          opacity: 0.9;
        }
        .val {
          font-size: 32px;
          opacity: 0.95;
        }
        .meta {
          opacity: 0.75;
          font-size: 12px;
          line-height: 1.35;
          margin-top: 3px;
        }
        .art {
          margin-top: 10px;
          border-radius: 14px;
          border: 1px dashed rgba(255, 255, 255, 0.14);
          padding: 14px;
          text-align: center;
          opacity: 0.55;
        }
        .hiddenCard {
          opacity: 0.9;
        }
        .empty {
          grid-column: 1 / -1;
          padding: 18px;
          border-radius: 16px;
          border: 1px dashed rgba(255, 255, 255, 0.16);
          text-align: center;
          opacity: 0.7;
        }
      `}</style>
    </div>
  );
}
